import React, { Component } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Cat from '../../img/cat.jpg';
import Dog from '../../img/dog.jpg';
import Friends from '../../img/friends.jpg';
import Hedgehog from '../../img/hedgehog.jpg';
import Bulldog from '../../img/bulldog.jpg';
import Puppy from '../../img/puppy.jpg';

export default class SimpleSlider extends Component {
  render() {
    const settings = {
      dots: false,
      arrows: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1
    };
    return (
      <div style={{ paddingTop: "134px", backgroundColor: "orange" }}>
        <Slider {...settings}>
          <div>
            <img src={Bulldog} alt="bulldog" width="100%" />
          </div>
          <div>
            <img src={Cat} alt="cat" width="100%" />
          </div>
          <div>
            <img src={Dog} alt="dog" width="100%" />
          </div>
          <div>
            <img src={Friends} alt="Friends" width="100%" />
          </div>
          <div>
            <img src={Hedgehog} alt="Hedgehog" width="100%" />
          </div>
          <div>
            <img src={Puppy} alt="Puppy" width="100%" />
          </div>
        </Slider>
      </div>
    );
  }
}