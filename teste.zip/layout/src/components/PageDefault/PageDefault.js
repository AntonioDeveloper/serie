import React from 'react'
import styled from 'styled-components';
import Menu from '../Menu/Menu';
import Footer from '../Footer/Footer';
import Top from '../Top/Top';

const Main = styled.div`
flex: 1;
width: 100%;
`;

export default function pageDefault({ children }) {
  return (
    <div>
      <Top />
      <Menu />
      <Main>
        {children}
      </Main>
      <Footer />
    </div>
  )
}
