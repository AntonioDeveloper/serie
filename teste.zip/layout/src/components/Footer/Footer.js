import React from 'react';
import { FooterBase, ListaContainer, ListaItem } from './Styles';
import logo from '../../img/logo.jpg';
import cartoes from '../../img/cartoes.jpg';
import { library } from '@fortawesome/fontawesome-svg-core';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faFacebook,
  faInstagram,
  faTwitter
} from '@fortawesome/free-brands-svg-icons';

library.add(
  faFacebook,
  faInstagram,
  faTwitter
);


export default function Footer() {

  return (
    <FooterBase>
      <div>
        <img src={logo} alt="Logo da loja" />
        <ListaContainer style={{ display: "flex", justifyContent: "center" }}>
          <ListaItem><FontAwesomeIcon icon={faFacebook} size="2x" style={{ margin: "0 10px", color: "gray" }} /></ListaItem>
          <ListaItem><FontAwesomeIcon icon={faInstagram} size="2x" style={{ margin: "0 10px", color: "gray" }} /></ListaItem>
          <ListaItem><FontAwesomeIcon icon={faTwitter} size="2x" style={{ margin: "0 10px", color: "gray" }} /></ListaItem>
        </ListaContainer>
        <p style={{ textAlign: "center", fontSize: "12px" }}>
          @2019 - CNPJ 00.000.000/0000-00 <br />
Rua Tal de Tal, 123,- Cidade, Estado
        </p>
      </div>

      <div>
        <ListaContainer>
          <h6 style={{ marginBottom: "10px" }}>PET STORE</h6>
          <ListaItem>Quem Somos</ListaItem>
          <ListaItem>Como Comprar</ListaItem>
          <ListaItem>Trocas e Devoluções</ListaItem>
          <ListaItem>Frete e Entregas</ListaItem>
        </ListaContainer>
      </div>

      <div>
        <ListaContainer>
          <h6 style={{ marginBottom: "10px" }}>CONTATO</h6>
          <ListaItem>(99) 99999-9999</ListaItem>
          <ListaItem>(99) 99999-9999</ListaItem>
        </ListaContainer>
      </div>

      <div>
        <ListaContainer>
          <h6 style={{ marginBottom: "10px" }}>PAGAMENTO</h6>
          <img src={cartoes} alt="cartoes" />
        </ListaContainer>
      </div>
    </FooterBase>
  );
}

