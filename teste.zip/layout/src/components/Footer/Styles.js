import styled from 'styled-components';


const FooterBase = styled.footer`
  background-color: white;
  padding-top: 32px;
  padding-bottom: 32px;
  color: var(--white);
  text-align: center;
  display: flex;
  justify-content: space-evenly;
  @media (max-width: 800px) {
    margin-bottom: 50px;
  }
`;

const ListaContainer = styled.ul`
display: block;
width: 150px;
padding: 0;
text-align: left;
`;

const ListaItem = styled.li`
font-size: 12px;
margin: 0;
`;

export { FooterBase, ListaContainer, ListaItem };