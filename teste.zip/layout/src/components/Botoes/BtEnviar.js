import React from 'react';
import styled from 'styled-components';

const Button = styled.button`
background-color: orange;
color: white;
width: 100px;
height: 30px;
padding: 5px;
font-size: 12px;
text-align: center;
margin: 0 auto;
border: none;
`;

export default function BtEnviar() {
  return (
    <Button>
      ENVIAR
    </Button>
  )
}
