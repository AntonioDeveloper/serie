import React from 'react';
import styled from 'styled-components';

const Button = styled.main`
background-color: orange;
color: white;
width: 200px;
height: 30px;
padding: 5px;
font-size: 12px;
text-align: center;
margin: 0 auto;
`;

export default function BtVerTodos() {
  return (
    <Button>
      VER TODOS OS PRODUTOS
    </Button>
  )
}
