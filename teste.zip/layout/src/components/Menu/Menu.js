import React from 'react';
import './Menu.css';
import styled from 'styled-components';

const Barras = styled.div`
width: 35px;
  height: 3px;
  background-color: orange;
  margin: 6px 0;
  border-Radius: 10px;
`;

export default function Menu() {
  return (

    <header className='Menu'>
      <ul>
        <li>Categoria</li>
        <li>Categoria</li>
        <li>Categoria</li>
        <li>Categoria</li>
        <li>Categoria</li>
        <li>Categoria</li>
        <li>Categoria</li>
        <li>
          <Barras />
          <Barras />
          <Barras />
        </li>
      </ul>
    </header>
  );
}
