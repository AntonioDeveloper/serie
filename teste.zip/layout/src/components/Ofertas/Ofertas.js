import React from 'react';
import styled from 'styled-components';
import Button from '../Botoes/BtVerTodos';
import foto1 from '../../img/1.jpg';
import foto2 from '../../img/2.jpg';
import foto3 from '../../img/3.jpg';
import foto4 from '../../img/4.jpg';

const Produtos = styled.main`
width: 100%;
margin-top: 30px;
`;

export default function Ofertas() {
  return (
    <>
      <h2 style={{ color: "#999", textAlign: "center" }}> DESTAQUES </h2>
      <Produtos>
        <ul>
          <li>
            <div>
              <img src={foto1} alt="produto1" />
              <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
                <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
              </p>
            </div>
          </li>
          <li>
            <div>
              <img src={foto2} alt="produto2" />
              <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
                <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
              </p>
            </div>
          </li>

          <li>
            <div>
              <img src={foto3} alt="produto3" />
              <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
                <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
              </p>
            </div>
          </li>
          <li>
            <div>
              <img src={foto4} alt="produto4" />
              <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
                <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
              </p>
            </div>
          </li>
        </ul>
      </Produtos>

      <Produtos>
        <ul>
          <li>
            <div>
              <img src={foto1} alt="produto1" />
              <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
                <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
              </p>
            </div>
          </li>
          <li>
            <div>
              <img src={foto2} alt="produto2" />
              <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
                <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
              </p>
            </div>
          </li>

          <li>
            <div>
              <img src={foto3} alt="produto3" />
              <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
                <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
              </p>
            </div>
          </li>
          <li>
            <div>
              <img src={foto4} alt="produto4" />
              <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
                <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
              </p>
            </div>
          </li>
        </ul>
      </Produtos>
      <Button />
    </>
  )
}

