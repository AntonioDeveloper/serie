import React from 'react'
import Racoes from '../../img/racoes.jpg';
import Brinquedos from '../../img/brinquedos.jpg';
import Acessorios from '../../img/acessorios.jpg';

export default function Secoes() {
  return (
    <div style={{
      backgroundColor: "orange", height: "95px", width: "100%",
      display: "flex", justifyContent: "center", padding: "20px 0"
    }}>
      <img src={Racoes} alt="rações" style={{ marginRight: "10px" }} />
      <img src={Brinquedos} alt="brinquedos" style={{ marginRight: "10px" }} />
      <img src={Acessorios} alt="acessorios" />
    </div>
  )
}
