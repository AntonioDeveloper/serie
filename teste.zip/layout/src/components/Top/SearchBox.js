// import React, { Component } from 'react';
// //import ReactSearchBox from 'react-search-box';
// //import { library } from '@fortawesome/fontawesome-svg-core';
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import {
//   faSearch
// } from '@fortawesome/free-solid-svg-icons/faSearch';

// // library.add(
// //   faFacebook,
// //   faInstagram,
// //   faTwitter
// // );

// export default class SearchBox extends Component {
//   data = [
//     {
//       key: 'john',
//       value: 'John Doe',
//     },
//     {
//       key: 'jane',
//       value: 'Jane Doe',
//     },
//     {
//       key: 'mary',
//       value: 'Mary Phillips',
//     },
//     {
//       key: 'robert',
//       value: 'Robert',
//     },
//     {
//       key: 'karius',
//       value: 'Karius',
//     },
//   ]

//   render() {
//     return (
//       <ReactSearchBox
//         placeholder="Pesquisar..."
//         value=""
//         data={this.data}
//         callback={record => console.log(record)}
//       />
//     )
//   }
// }

import React from 'react'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faSearch
} from '@fortawesome/free-solid-svg-icons/faSearch';


export default function SearchBox() {
  return (
    <>
      <form action="#">
        <input type="text" placeholder="Pesquisar..." name="busca" style={{ borderRight: "none", padding: "5px", border: "1px solid #999" }} />
        <button type="submit" style={{ background: "none", borderLeft: "none", padding: "5px", border: "1px solid #999" }}><FontAwesomeIcon icon={faSearch} /></button>
      </form>
    </>

  )
}
