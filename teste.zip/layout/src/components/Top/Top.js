import React from 'react'
import './Top.css';
import SearchBox from './SearchBox';
import logo from '../../img/logo.jpg';
import login from '../../img/login.jpg';


export default function Top() {
  return (
    <>
      <div className="Topo">
        <SearchBox />
        <div className="containerLogo">
          <img src={logo} className="logo" alt="Logo" />
          <img src={login} alt="Área de login" width="105px" />
        </div>
      </div >
    </>
  )
}
