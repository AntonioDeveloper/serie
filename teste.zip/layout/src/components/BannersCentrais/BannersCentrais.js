import React from 'react';
import Gatos from '../../img/para-gatos.jpg';
import Caes from '../../img/para-caes.jpg';

export default function BannersCentrais() {
  return (
    <div style={{ width: "100%", display: "flex", justifyContent: "center" }}>
      <img src={Gatos} alt="para gatos" style={{ width: "30%", marginRight: "5px" }} />
      <img src={Caes} alt="para cães" style={{ width: "30%", marginLeft: "5px" }} />
    </div>
  )
}
