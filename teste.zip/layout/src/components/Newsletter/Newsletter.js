import React from 'react';
import styled from 'styled-components';
import BtEnviar from '../Botoes/BtEnviar';

const Bloco = styled.main`
width: 100%;
background-color: #9966cc;
color: white;
padding: 10px 0;
margin-top: 20px;
height: 200px;
`;

const Formulario = styled.div`
text-align: center;
`;

const Input = styled.input`
border: none;
border-bottom: 1px solid white;
background: none;
color: white;
margin-right: 10px;
padding: 5px 0;
&:focus{
  outline: none;
}
&::placeholder{
  color: white;
} 
`;

export default function Newsletter() {
  return (
    <Bloco>
      <div>
        <ul style={{ borderBottom: "1px solid orange", width: "70%" }}>
          <li>ENTREGA GRATUITA A PARTIR DE R$ 99</li>
          <li>PARCELAMENTO SEM JUROS</li>
          <li>CADASTRE-SE E GANHE DESCONTO</li>
        </ul>
      </div>

      <Formulario>
        <h3>ASSINE NOSSA NEWSLETTER</h3>
        <p> Cadastre-se para receber nossas novidades e descontos exclusivos!</p>
        <form>
          <Input type="text" id="nome" name="nome" placeholder="Nome" />

          <Input type="text" id="email" name="email" placeholder="E-mail" />

          <BtEnviar />
        </form>
      </Formulario>
    </Bloco>
  )
}
