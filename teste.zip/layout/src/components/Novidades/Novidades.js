import React, { Component } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import foto1 from '../../img/1.jpg';
import foto2 from '../../img/2.jpg';
import foto3 from '../../img/3.jpg';
import foto4 from '../../img/4.jpg';


export default class Novidades extends Component {
  render() {
    var settings = {
      dots: true,
      infinite: false,
      speed: 500,
      slidesToShow: 4,
      slidesToScroll: 4,
      initialSlide: 0,
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
            infinite: true,
            dots: true
          }
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
            initialSlide: 2
          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    };
    return (
      <div style={{ padding: "0 10% 5% " }}>
        <h2 style={{ color: "#999", textAlign: "center" }}> NOVIDADES </h2>
        <Slider {...settings}>
          <div>
            <img src={foto1} alt="produto1" />
            <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
              <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
            </p>
          </div>

          <div>
            <img src={foto2} alt="produto2" />
            <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
              <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
            </p>
          </div>

          <div>
            <img src={foto3} alt="produto3" />
            <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
              <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
            </p>
          </div>

          <div>
            <img src={foto4} alt="produto4" />
            <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
              <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
            </p>
          </div>

          <div>
            <img src={foto2} alt="produto2" />
            <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
              <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
            </p>
          </div>

          <div>
            <img src={foto1} alt="produto1" />
            <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
              <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
            </p>
          </div>

          <div>
            <img src={foto3} alt="produto3" />
            <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
              <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
            </p>
          </div>

          <div>
            <img src={foto4} alt="produto4" />
            <p style={{ textAlign: "center", color: "#999" }}>Simulação de texto <br />
              <span style={{ fontWeight: "bold" }}>R$ 9,99</span>
            </p>
          </div>
        </Slider>
      </div>
    );
  }
}