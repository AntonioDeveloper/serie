import React from 'react';
import PageDefault from './components/PageDefault/PageDefault';
import SimpleSlider from './components/Banners/Banners';
import Secoes from './components/Secoes/Secoes';
import Novidades from './components/Novidades/Novidades';
import BannersCentrais from './components/BannersCentrais/BannersCentrais';
import Ofertas from './components/Ofertas/Ofertas';
import Newsletter from './components/Newsletter/Newsletter';

function App() {
  return (
    <div width={{ maxWidth: "1170px" }}>
      <PageDefault>
        <SimpleSlider />
        <Secoes />
        <Novidades />
        <BannersCentrais />
        <Ofertas />
        <Newsletter />
      </PageDefault>
    </div>
  );
}

export default App;


